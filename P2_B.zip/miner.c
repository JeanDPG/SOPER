/**
 * @file miner.c
 * @brief Programa minero
 * @date 06-04-2026
 */

#define _POSIX_C_SOURCE 200809L
#define _DEFAULT_SOURCE

#include <fcntl.h>
#include <semaphore.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>
#include "miner.h"
#include "pow.h"


static volatile sig_atomic_t finish = 0;
static volatile sig_atomic_t start_round = 0;
static volatile sig_atomic_t voting_round = 0;

static pid_t my_pid;
static int is_first_miner = 0;


static void handle_alarm(int sig) {
    (void)sig;
    finish = 1;
}

static void handle_sigusr1(int sig) {
    (void)sig;
    start_round = 1;
}

static void handle_sigusr2(int sig) {
    (void)sig;
    voting_round = 1;
}


static void configurar_manejadores(void) {
    struct sigaction act;
    
    act.sa_handler = handle_alarm;
    sigemptyset(&act.sa_mask);
    act.sa_flags = 0;
    sigaction(SIGALRM, &act, NULL);
    
    act.sa_handler = handle_sigusr1;
    sigemptyset(&act.sa_mask);
    act.sa_flags = 0;
    sigaction(SIGUSR1, &act, NULL);
    
    act.sa_handler = handle_sigusr2;
    sigemptyset(&act.sa_mask);
    act.sa_flags = 0;
    sigaction(SIGUSR2, &act, NULL);
}



void init_semaphore(void) {
    sem_t *sem = sem_open(SEM_MUTEX, O_CREAT | O_EXCL, S_IRUSR | S_IWUSR, 1);
    if (sem == SEM_FAILED) {
        sem = sem_open(SEM_MUTEX, 0);
        if (sem == SEM_FAILED) {
            perror("sem_open");
            exit(EXIT_FAILURE);
        }
    }
    sem_close(sem);
}

void delete_semaphore(void) {
    sem_unlink(SEM_MUTEX);
}

void init_round_semaphores(void) {
    sem_t *sem;
    
    sem_unlink(SEM_TARGET);
    sem_unlink(SEM_VOTING);
    sem_unlink(SEM_RACE);
    
    sem = sem_open(SEM_TARGET, O_CREAT | O_EXCL, S_IRUSR | S_IWUSR, 1);
    if (sem == SEM_FAILED) perror("sem_open SEM_TARGET");
    else sem_close(sem);
    
    sem = sem_open(SEM_VOTING, O_CREAT | O_EXCL, S_IRUSR | S_IWUSR, 1);
    if (sem == SEM_FAILED) perror("sem_open SEM_VOTING");
    else sem_close(sem);
    
    sem = sem_open(SEM_RACE, O_CREAT | O_EXCL, S_IRUSR | S_IWUSR, 1);
    if (sem == SEM_FAILED) perror("sem_open SEM_RACE");
    else sem_close(sem);
}

void delete_round_semaphores(void) {
    sem_unlink(SEM_TARGET);
    sem_unlink(SEM_VOTING);
    sem_unlink(SEM_RACE);
}



void add_miner_to_system(pid_t pid) {
    sem_t *sem = sem_open(SEM_MUTEX, 0);
    if (sem == SEM_FAILED) {
        perror("sem_open");
        exit(EXIT_FAILURE);
    }
    
    sem_wait(sem);
    FILE *file = fopen(FILE_SYSTEM, "a");
    if (file == NULL) {
        perror("fopen");
        sem_post(sem);
        sem_close(sem);
        exit(EXIT_FAILURE);
    }
    fprintf(file, "%d\n", pid);
    fclose(file);
    sem_post(sem);
    sem_close(sem);
}

void remove_miner_from_system(pid_t pid) {
    sem_t *sem = sem_open(SEM_MUTEX, 0);
    if (sem == SEM_FAILED) {
        perror("sem_open");
        exit(EXIT_FAILURE);
    }
    
    sem_wait(sem);
    FILE *file = fopen(FILE_SYSTEM, "r");
    if (file == NULL) {
        sem_post(sem);
        sem_close(sem);
        return;
    }
    
    int pids[TAM];
    int count = 0;
    int current_pid;
    
    while (fscanf(file, "%d", &current_pid) == 1) {
        if (current_pid != pid) pids[count++] = current_pid;
    }
    fclose(file);
    
    if (count == 0) {
        unlink(FILE_SYSTEM);
    } else {
        file = fopen(FILE_SYSTEM, "w");
        if (file != NULL) {
            for (int i = 0; i < count; i++) fprintf(file, "%d\n", pids[i]);
            fclose(file);
        }
    }
    sem_post(sem);
    sem_close(sem);
}

int get_active_miners(void) {
    sem_t *sem = sem_open(SEM_MUTEX, 0);
    if (sem == SEM_FAILED) return 0;
    
    sem_wait(sem);
    FILE *file = fopen(FILE_SYSTEM, "r");
    if (file == NULL) {
        sem_post(sem);
        sem_close(sem);
        return 0;
    }
    
    int count = 0, dummy;
    while (fscanf(file, "%d", &dummy) == 1) count++;
    fclose(file);
    
    sem_post(sem);
    sem_close(sem);
    return count;
}

void delete_system_file(void) {
    unlink(FILE_SYSTEM);
}



void write_target(int target) {
    sem_t *sem = sem_open(SEM_TARGET, 0);
    if (sem == SEM_FAILED) return;
    
    sem_wait(sem);
    FILE *file = fopen(FILE_TARGET, "w");
    if (file != NULL) {
        fprintf(file, "%d\n", target);
        fclose(file);
    }
    sem_post(sem);
    sem_close(sem);
}

int read_target(void) {
    sem_t *sem = sem_open(SEM_TARGET, 0);
    if (sem == SEM_FAILED) return -1;
    
    sem_wait(sem);
    FILE *file = fopen(FILE_TARGET, "r");
    if (file == NULL) {
        sem_post(sem);
        sem_close(sem);
        return -1;
    }
    
    int target;
    if (fscanf(file, "%d", &target) != 1) target = -1;
    fclose(file);
    
    sem_post(sem);
    sem_close(sem);
    return target;
}



void cast_vote(char vote) {
    sem_t *sem = sem_open(SEM_VOTING, 0);
    if (sem == SEM_FAILED) return;
    
    sem_wait(sem);
    FILE *file = fopen(FILE_VOTING, "a");
    if (file != NULL) {
        fprintf(file, "%c\n", vote);
        fclose(file);
    }
    sem_post(sem);
    sem_close(sem);
}

int count_yes_votes(void) {
    sem_t *sem = sem_open(SEM_VOTING, 0);
    if (sem == SEM_FAILED) return 0;
    
    sem_wait(sem);
    FILE *file = fopen(FILE_VOTING, "r");
    if (file == NULL) {
        sem_post(sem);
        sem_close(sem);
        return 0;
    }
    
    int yes = 0;
    char vote;
    while (fscanf(file, " %c", &vote) == 1) if (vote == 'Y') yes++;
    fclose(file);
    
    sem_post(sem);
    sem_close(sem);
    return yes;
}

int count_total_votes(void) {
    sem_t *sem = sem_open(SEM_VOTING, 0);
    if (sem == SEM_FAILED) return 0;
    
    sem_wait(sem);
    FILE *file = fopen(FILE_VOTING, "r");
    if (file == NULL) {
        sem_post(sem);
        sem_close(sem);
        return 0;
    }
    
    int total = 0;
    char vote;
    while (fscanf(file, " %c", &vote) == 1) total++;
    fclose(file);
    
    sem_post(sem);
    sem_close(sem);
    return total;
}

void clear_voting_file(void) {
    sem_t *sem = sem_open(SEM_VOTING, 0);
    if (sem == SEM_FAILED) return;
    
    sem_wait(sem);
    FILE *file = fopen(FILE_VOTING, "w");
    if (file != NULL) fclose(file);
    sem_post(sem);
    sem_close(sem);
}



void wait_for_signal(int sig) {
    sigset_t mask;
    sigemptyset(&mask);
    sigsuspend(&mask);
}

void signal_all_miners(int sig) {
    sem_t *sem = sem_open(SEM_MUTEX, 0);
    if (sem == SEM_FAILED) return;
    
    sem_wait(sem);
    FILE *file = fopen(FILE_SYSTEM, "r");
    if (file != NULL) {
        int pid;
        while (fscanf(file, "%d", &pid) == 1) {
            if (pid != getpid()) kill(pid, sig);
        }
        fclose(file);
    }
    sem_post(sem);
    sem_close(sem);
}

int try_become_winner(void) {
    sem_t *sem = sem_open(SEM_RACE, 0);
    if (sem == SEM_FAILED) return 0;
    
    if (sem_trywait(sem) == 0) {
        sem_close(sem);
        return 1;
    }
    sem_close(sem);
    return 0;
}

int validate_solution(int solution, int target) {
    return (pow_hash(solution) == target);
}

void wait_for_votes(int total_miners) {
    int attempts = 0;
    while (attempts < MAX_RETRIES && count_total_votes() < total_miners - 1) {
        usleep(TIMEOUT_USEC);
        attempts++;
    }
}

void show_results(int winner_pid, int yes_votes, int total_votes) {
    sem_t *sem = sem_open(SEM_VOTING, 0);
    if (sem == SEM_FAILED) return;
    
    sem_wait(sem);
    FILE *file = fopen(FILE_VOTING, "r");
    if (file == NULL) {
        sem_post(sem);
        sem_close(sem);
        return;
    }
    
    char votes[TAM];
    int count = 0;
    char vote;
    while (fscanf(file, " %c", &vote) == 1 && count < TAM - 1) {
        votes[count++] = vote;
    }
    fclose(file);
    sem_post(sem);
    sem_close(sem);
    
    printf("Winner %d => [ ", winner_pid);
    for (int i = 0; i < count; i++) {
        printf("%c ", votes[i]);
    }
    printf("] => %s\n", (yes_votes >= (total_votes - yes_votes)) ? "Accepted" : "Rejected");
}

int main(int argc, char *argv[]) {
    int n_secs, n_threads;
    int target, solution;
    int winner_pid = -1;
    int yes_votes, total_votes;
    int round_number = 0;
    
    if (argc != 3) {
        fprintf(stderr, "Uso: %s <N_SECS> <N_THREADS>\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    n_secs = atoi(argv[1]);
    n_threads = atoi(argv[2]);
    my_pid = getpid();
    (void)n_threads;
    
    configurar_manejadores();
    init_semaphore();
    init_round_semaphores();
    
    add_miner_to_system(my_pid);
    printf("Miner %d added to system\n", my_pid);
    
    if (get_active_miners() == 1) {
        is_first_miner = 1;
        write_target(0);
        printf("First miner %d created target.txt\n", my_pid);
    }
    
    alarm(n_secs);
    
    while (!finish) {

        while (get_active_miners() < 2 && !finish) {
            usleep(100000);
        }
        
        if (finish) break;
        

        if ((round_number == 0 && is_first_miner) || 
            (round_number > 0 && winner_pid == my_pid)) {
            printf("Miner %d starting round %d\n", my_pid, round_number + 1);
            signal_all_miners(SIGUSR1);

            start_round = 1;
        } else {

            start_round = 0;
            while (!start_round && !finish) {
                wait_for_signal(SIGUSR1);
            }
        }
        
        if (finish) break;
        

        target = read_target();
        if (target == -1) target = 0;
        solution = target + 1;
        

        if (try_become_winner()) {

            winner_pid = my_pid;
            printf("Miner %d is the WINNER of round %d (target=%d, solution=%d)\n",
                   my_pid, round_number + 1, target, solution);
            
            write_target(solution);
            signal_all_miners(SIGUSR2);
            usleep(100000);
            
            total_votes = get_active_miners();
            wait_for_votes(total_votes);
            
            yes_votes = count_yes_votes();
            total_votes = count_total_votes();
            
            show_results(my_pid, yes_votes, total_votes);
            
            if (yes_votes >= (total_votes - yes_votes)) {
                printf("Miner %d wins a coin!\n", my_pid);
            }
            
            clear_voting_file();
            round_number++;
            
        } else {

            voting_round = 0;
            while (!voting_round && !finish) {
                wait_for_signal(SIGUSR2);
            }
            
            if (!finish) {
                target = read_target();
                if (validate_solution(solution, target)) {
                    cast_vote('Y');
                    printf("Miner %d voted: Y\n", my_pid);
                } else {
                    cast_vote('N');
                    printf("Miner %d voted: N\n", my_pid);
                }
            }
        }
    }
    

    remove_miner_from_system(my_pid);
    printf("Miner %d exited system\n", my_pid);
    
    if (get_active_miners() == 0) {
        delete_system_file();
        delete_semaphore();
        delete_round_semaphores();
        unlink(FILE_TARGET);
        unlink(FILE_VOTING);
        printf("Last miner cleaned up system files\n");
    }
    
    return EXIT_SUCCESS;
}