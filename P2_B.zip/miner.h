/**
 * @file miner.h
 * @brief Funciones del programa minero
 * @date 06-04-2026
 */

#ifndef MINER_H
#define MINER_H

#include <sys/types.h>

//Ficheros
#define FILE_SYSTEM "system.txt"
#define FILE_TARGET "target.txt"
#define FILE_VOTING "voting.txt"

//Semáforos
#define SEM_MUTEX "/sem_mutex"
#define SEM_TARGET "/sem_target"
#define SEM_VOTING "/sem_voting"
#define SEM_RACE "/sem_race"

#define TAM 1024
#define MAX_RETRIES 10
#define TIMEOUT_USEC 100000


/**
 * @brief Inicializa el semáforo mutex para el fichero de PIDs
 */
void init_semaphore(void);

/**
 * @brief Elimina el semáforo mutex del sistema
 */
void delete_semaphore(void);

/**
 * @brief Inicializa los semáforos necesarios para las rondas
 */
void init_round_semaphores(void);

/**
 * @brief Elimina los semáforos de las rondas del sistema
 */
void delete_round_semaphores(void);



/**
 * @brief Añade el PID del minero al fichero del sistema
 * @param pid PID del proceso minero a añadir
 */
void add_miner_to_system(pid_t pid);

/**
 * @brief Elimina el PID del minero del fichero del sistema
 * @param pid PID del proceso minero a eliminar
 */
void remove_miner_from_system(pid_t pid);

/**
 * @brief Obtiene el número de mineros activos en el sistema
 * @return Número de mineros activos
 */
int get_active_miners(void);

/**
 * @brief Elimina el fichero del sistema
 */
void delete_system_file(void);



/**
 * @brief Escribe el objetivo actual en el fichero target.txt
 * @param target Objetivo a escribir
 */
void write_target(int target);

/**
 * @brief Lee el objetivo actual del fichero target.txt
 * @return Objetivo actual, o -1 si error
 */
int read_target(void);



/**
 * @brief Añade un voto al fichero de votación
 * @param vote 'Y' para válido, 'N' para no válido
 */
void cast_vote(char vote);

/**
 * @brief Cuenta el número de votos 'Y' en el fichero de votación
 * @return Número de votos positivos
 */
int count_yes_votes(void);

/**
 * @brief Cuenta el número total de votos en el fichero de votación
 * @return Número total de votos
 */
int count_total_votes(void);

/**
 * @brief Limpia el fichero de votación para una nueva ronda
 */
void clear_voting_file(void);



/**
 * @brief Espera una señal de forma no activa
 * @param sig Número de la señal a esperar
 */
void wait_for_signal(int sig);

/**
 * @brief Envía una señal a todos los mineros activos
 * @param sig Número de la señal a enviar
 */
void signal_all_miners(int sig);

/**
 * @brief Intenta convertirse en el ganador de la ronda
 * @return 1 si es el ganador, 0 si no lo es
 */
int try_become_winner(void);

/**
 * @brief Valida si una solución es correcta para el objetivo dado
 * @param solution Solución encontrada
 * @param target Objetivo a cumplir
 * @return 1 si es correcto, 0 en caso contrario
 */
int validate_solution(int solution, int target);

/**
 * @brief Espera no activa hasta recibir todos los votos
 * @param total_miners Número total de mineros votantes
 */
void wait_for_votes(int total_miners);

/**
 * @brief Muestra los resultados de la votación
 * @param winner_pid PID del minero ganador
 * @param yes_votes Número de votos positivos (Y)
 * @param total_votes Número total de votos emitidos
 */
void show_results(int winner_pid, int yes_votes, int total_votes);

#endif