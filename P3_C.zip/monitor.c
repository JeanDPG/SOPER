#include "monitor.h"
#include "pow.h"
#include "definiciones.h"
#include <string.h>

// proceso comprobador (productor)
void ejecutar_comprobador(int lag_comprobador) {
    mqd_t mq;
    sem_t *sem_empty, *sem_fill, *sem_mutex;
    int shm_fd;
    SharedMemory *shm;
    struct mq_attr attr;
    
    // crear semaforos
    sem_unlink(SEM_EMPTY);
    sem_unlink(SEM_FILL);
    sem_unlink(SEM_MUTEX);
    
    sem_empty = sem_open(SEM_EMPTY, O_CREAT | O_EXCL, 0666, BUFFER_SIZE);
    sem_fill = sem_open(SEM_FILL, O_CREAT | O_EXCL, 0666, 0);
    sem_mutex = sem_open(SEM_MUTEX, O_CREAT | O_EXCL, 0666, 1);
    
    if (sem_empty == SEM_FAILED || sem_fill == SEM_FAILED || sem_mutex == SEM_FAILED) {
        perror("sem_open");
        exit(EXIT_FAILURE);
    }
    
    // crear memoria compartida
    shm_fd = shm_open(SHM_NAME, O_CREAT | O_RDWR, 0666);
    if (shm_fd == -1) {
        perror("shm_open");
        exit(EXIT_FAILURE);
    }
    
    if (ftruncate(shm_fd, sizeof(SharedMemory)) == -1) {
        perror("ftruncate");
        close(shm_fd);
        exit(EXIT_FAILURE);
    }
    
    shm = mmap(NULL, sizeof(SharedMemory), PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);
    if (shm == MAP_FAILED) {
        perror("mmap");
        close(shm_fd);
        exit(EXIT_FAILURE);
    }
    close(shm_fd);
    
    // inicializar buffer circular
    shm->in = 0;
    shm->out = 0;
    shm->terminado = 0;
    
    // crear cola de mensajes
    attr.mq_flags = 0;
    attr.mq_maxmsg = 7;
    attr.mq_msgsize = sizeof(MqMessage);
    attr.mq_curmsgs = 0;
    
    mq_unlink(MQ_NAME_MINER);
    mq = mq_open(MQ_NAME_MINER, O_CREAT | O_RDONLY, 0666, &attr);
    if (mq == (mqd_t)-1) {
        perror("mq_open");
        exit(EXIT_FAILURE);
    }
    
    // bucle principal del comprobador (productor)
    int fin_sistema = 0;
    while (!fin_sistema) {
        MqMessage msg_recibida;
        
        ssize_t n = mq_receive(mq, (char*)&msg_recibida, sizeof(MqMessage), NULL);
        
        if (n == -1) {
            continue;
        }
        
        if (n == sizeof(MqMessage)) {
            if (msg_recibida.es_fin == 1) {
                // bloque de finalizacion
                sem_wait(sem_empty);
                sem_wait(sem_mutex);
                
                shm->buffer[shm->in].objetivo = 0;
                shm->buffer[shm->in].solucion = -1;
                shm->buffer[shm->in].validado = -1;
                shm->in = (shm->in + 1) % BUFFER_SIZE;
                
                sem_post(sem_mutex);
                sem_post(sem_fill);
                
                fin_sistema = 1;
            } else {
                int es_valido = (pow_hash(msg_recibida.solucion) == msg_recibida.objetivo);
                
                // productor: meter en buffer
                sem_wait(sem_empty);
                sem_wait(sem_mutex);
                
                shm->buffer[shm->in].objetivo = msg_recibida.objetivo;
                shm->buffer[shm->in].solucion = msg_recibida.solucion;
                shm->buffer[shm->in].validado = es_valido ? 1 : 0;
                shm->in = (shm->in + 1) % BUFFER_SIZE;
                
                sem_post(sem_mutex);
                sem_post(sem_fill);
            }
        }
        
        usleep(lag_comprobador * 1000);
    }
    
    // marcar terminado
    shm->terminado = 1;
    
    // esperar a que el monitor termine
    sleep(1);
    
    // limpiar recursos
    mq_close(mq);
    mq_unlink(MQ_NAME_MINER);
    
    munmap(shm, sizeof(SharedMemory));
    shm_unlink(SHM_NAME);
    
    sem_close(sem_empty);
    sem_close(sem_fill);
    sem_close(sem_mutex);
    sem_unlink(SEM_EMPTY);
    sem_unlink(SEM_FILL);
    sem_unlink(SEM_MUTEX);
    
    exit(EXIT_SUCCESS);
}

// proceso monitor (consumidor)
void ejecutar_monitor(int lag_monitor) {
    int shm_fd;
    SharedMemory *shm;
    sem_t *sem_empty, *sem_fill, *sem_mutex;
    Bloque bloque_actual;
    
    // esperar a que el comprobador cree los recursos
    sleep(1);
    
    // abrir memoria compartida
    shm_fd = shm_open(SHM_NAME, O_RDWR, 0666);
    if (shm_fd == -1) {
        perror("shm_open");
        exit(EXIT_FAILURE);
    }
    
    shm = mmap(NULL, sizeof(SharedMemory), PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);
    if (shm == MAP_FAILED) {
        perror("mmap");
        close(shm_fd);
        exit(EXIT_FAILURE);
    }
    close(shm_fd);
    
    // abrir semaforos
    sem_empty = sem_open(SEM_EMPTY, 0);
    sem_fill = sem_open(SEM_FILL, 0);
    sem_mutex = sem_open(SEM_MUTEX, 0);
    
    if (sem_empty == SEM_FAILED || sem_fill == SEM_FAILED || sem_mutex == SEM_FAILED) {
        perror("sem_open");
        exit(EXIT_FAILURE);
    }
    
    // bucle principal del monitor (consumidor)
    while (!shm->terminado) {
        sem_wait(sem_fill);
        sem_wait(sem_mutex);
        
        bloque_actual = shm->buffer[shm->out];
        shm->out = (shm->out + 1) % BUFFER_SIZE;
        
        sem_post(sem_mutex);
        sem_post(sem_empty);
        
        if (bloque_actual.validado == 1) {
            printf("Solution accepted: %08d --> %08d\n", 
                   bloque_actual.objetivo, bloque_actual.solucion);
        } else if (bloque_actual.validado == 0) {
            printf("Solution rejected: %08d !-> %08d\n", 
                   bloque_actual.objetivo, bloque_actual.solucion);
        }
        
        fflush(stdout);
        usleep(lag_monitor * 1000);
    }
    
    // limpiar recursos
    munmap(shm, sizeof(SharedMemory));
    sem_close(sem_empty);
    sem_close(sem_fill);
    sem_close(sem_mutex);
    
    exit(EXIT_SUCCESS);
}

// programa principal
int main(int argc, char *argv[]) {
    int lag_comprobador, lag_monitor;
    pid_t pid_monitor;
    
    if (argc != 3) {
        fprintf(stderr, "uso: %s <lag_comprobador> <lag_monitor>\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    lag_comprobador = atoi(argv[1]);
    lag_monitor = atoi(argv[2]);
    
    pid_monitor = fork();
    
    if (pid_monitor == -1) {
        perror("fork");
        exit(EXIT_FAILURE);
    }
    
    if (pid_monitor == 0) {
        // proceso hijo: monitor (consumidor)
        ejecutar_monitor(lag_monitor);
    } else {
        // proceso padre: comprobador (productor)
        ejecutar_comprobador(lag_comprobador);
    }
    
    return 0;
}