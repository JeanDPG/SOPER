#ifndef MONITOR_H
#define MONITOR_H

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <semaphore.h>
#include <mqueue.h>

// constantes para la cola de mensajes (apartado b)
#define MQ_NAME_MINER   "/mq_miner_monitor"
#define MAX_QUEUE_SIZE  7

// constantes para memoria compartida (apartado c)
#define SHM_NAME       "/shm_monitor"
#define BUFFER_SIZE    6

// constantes para semaforos (apartado c)
#define SEM_EMPTY      "/sem_empty"
#define SEM_FILL       "/sem_fill"
#define SEM_MUTEX      "/sem_mutex"

// estructura para un bloque de informacion (apartado c)
typedef struct {
    int objetivo;
    int solucion;
    int validado;      // 1 = correcto, 0 = incorrecto, -1 = finalizacion
} Bloque;

// estructura para la memoria compartida (buffer circular productor-consumidor)
typedef struct {
    Bloque buffer[BUFFER_SIZE];
    int in;            // indice de escritura (productor)
    int out;           // indice de lectura (consumidor)
    int terminado;     // flag para indicar fin del sistema
} SharedMemory;

#endif