#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <semaphore.h>
#include <errno.h>
#include <signal.h>
#include <string.h>
#include <mqueue.h>

#include "minero.h"
#include "definiciones.h"
#include "pow.h"

#define SEM_NAME      "/mutex_minero"
#define SEM_WINNER    "/sem_winner"
#define FILE_PIDS     "processPID.txt"
#define FILE_TARGET   "target.txt"
#define FILE_VOTOS    "votos.txt"
#define MAX_VOTOS_INTENTOS 50

volatile sig_atomic_t got_SIGALRM = 0;
volatile sig_atomic_t got_SIGUSR1 = 0;
volatile sig_atomic_t got_SIGUSR2 = 0;
volatile sig_atomic_t got_SIGINT = 0;

// manejador de señales
void handler(int sig) {
    if      (sig == SIGALRM) got_SIGALRM = 1;
    else if (sig == SIGUSR1) got_SIGUSR1 = 1;
    else if (sig == SIGUSR2) got_SIGUSR2 = 1;
    else if (sig == SIGINT)  got_SIGINT = 1;
}

// funcion: powRank (hilos)
void* powRank(void* arg) {
    Rank* r = (Rank*) arg;
    for (int i = r->start; i < r->stop; i++) {
        if (*(r->found) != -1) {
            free(r);
            return NULL;
        }
        if (pow_hash(i) == r->target) {
            if (*(r->found) == -1) {
                *(r->found) = i;
            }
            free(r);
            return NULL;
        }
    }
    free(r);
    return NULL;
}

// funcion: escritura_de_ficheroPIDS
void escritura_de_ficheroPIDS(pid_t pid) {
    int fd = open(FILE_PIDS, O_WRONLY | O_APPEND | O_CREAT, 0644);
    if (fd == -1) {
        perror("open processPID.txt");
        exit(EXIT_FAILURE);
    }
    char buffer[64];
    int len = snprintf(buffer, sizeof(buffer), "%d\n", pid);
    write(fd, buffer, len);
    close(fd);
}

// funcion: leer_Target
void leer_Target(pid_t pid, int *init_target) {
    int fd3 = open(FILE_TARGET, O_WRONLY | O_CREAT | O_EXCL, 0644);
    if (fd3 != -1) {
        char buffer[64];
        int len = snprintf(buffer, sizeof(buffer), "%d\n", *init_target);
        write(fd3, buffer, len);
        close(fd3);
    } else if (errno == EEXIST) {
        fd3 = open(FILE_TARGET, O_RDONLY);
        if (fd3 != -1) {
            char read_buffer[64];
            int n = read(fd3, read_buffer, sizeof(read_buffer)-1);
            if (n > 0) {
                read_buffer[n] = '\0';
                *init_target = atoi(read_buffer);
            }
            close(fd3);
        }
    }
}

// funcion: escribir_Target
void escribir_Target(int nuevo_target) {
    const char *tmp = "target.tmp";
    int fd = open(tmp, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd != -1) {
        char buffer[32];
        int len = snprintf(buffer, sizeof(buffer), "%d\n", nuevo_target);
        write(fd, buffer, len);
        close(fd);
        rename(tmp, FILE_TARGET);
    }
}

// funcion: contar_votos
int contar_votos() {
    int fd = open(FILE_VOTOS, O_RDONLY);
    if (fd == -1) return 0;
    int count = 0; char c;
    while (read(fd, &c, 1) > 0) {
        if (c == 'Y' || c == 'N') count++;
    }
    close(fd);
    return count;
}

// funcion: votar
void votar(int target_a_validar, sem_t *sem) {
    sem_wait(sem);

    int fd_read = open(FILE_TARGET, O_RDONLY);
    char buf[32] = {0};
    if (fd_read != -1) {
        int n = read(fd_read, buf, sizeof(buf)-1);
        if (n > 0) buf[n] = '\0';
        close(fd_read);
    }
    int sol = atoi(buf);

    char voto = (pow_hash(sol) == target_a_validar) ? 'Y' : 'N';

    int fd_write = open(FILE_VOTOS, O_WRONLY | O_APPEND | O_CREAT, 0644);
    if (fd_write != -1) {
        write(fd_write, &voto, 1);
        close(fd_write);
    }

    sem_post(sem);
}

// funcion: contar_y_mostrar_votos
int contar_y_mostrar_votos(pid_t ganador_pid, int *monedas, sem_t *sem) {
    sem_wait(sem);
    int fd = open(FILE_VOTOS, O_RDONLY);
    if (fd == -1) { sem_post(sem); return 0; }
    char v_buf[256];
    int n = read(fd, v_buf, sizeof(v_buf)-1);
    close(fd);
    sem_post(sem);
    v_buf[n] = '\0';

    int yes = 0, no = 0;
    char lista[512] = "";
    for (int i = 0; i < n; i++) {
        if (v_buf[i] == 'Y') { yes++; strcat(lista, "Y "); }
        else if (v_buf[i] == 'N') { no++; strcat(lista, "N "); }
    }
    int aceptado = (yes >= no);
    printf("Winner %d => [ %s] => %s\n", ganador_pid, lista, aceptado ? "Accepted" : "Rejected");
    fflush(stdout);
    if (aceptado) (*monedas)++;
    return aceptado;
}

// funcion: contar_mineros_en_fichero
int contar_mineros_en_fichero() {
    int fd = open(FILE_PIDS, O_RDONLY);
    if (fd == -1) return 0;
    int count = 0; char c, last_char = 0;
    while (read(fd, &c, 1) > 0) {
        if (c == '\n') count++;
        last_char = c;
    }
    if (last_char != '\n' && last_char != 0) count++;
    close(fd);
    return count;
}

// funcion: notificar_a_todos
void notificar_a_todos(pid_t mi_pid, int senial) {
    int fd = open(FILE_PIDS, O_RDONLY);
    if (fd == -1) return;
    char c, buf_pid[16]; int i = 0;
    while (read(fd, &c, 1) > 0) {
        if (c == '\n') {
            buf_pid[i] = '\0';
            pid_t p = (pid_t)atoi(buf_pid);
            if (p > 0 && p != mi_pid) kill(p, senial);
            i = 0;
        } else if (i < 15) buf_pid[i++] = c;
    }
    if (i > 0) {
        buf_pid[i] = '\0';
        pid_t p = (pid_t)atoi(buf_pid);
        if (p > 0 && p != mi_pid) kill(p, senial);
    }
    close(fd);
}

// funcion: limpiar_votos
void limpiar_votos() {
    unlink(FILE_VOTOS);
}

// funcion: borrado_de_ficheros
void borrado_de_ficheros(pid_t pid_to_delete) {
    char aux[64];
    snprintf(aux, sizeof(aux), "processPID_aux_%d.txt", (int)pid_to_delete);

    int fd1 = open(FILE_PIDS, O_RDONLY);
    int fd2 = open(aux, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd1 == -1) { if (fd2 != -1) close(fd2); return; }
    char c, line[64]; int j = 0, restantes = 0;
    while (read(fd1, &c, 1) > 0) {
        if (c == '\n') {
            line[j] = '\0';
            if ((pid_t)atoi(line) != pid_to_delete) {
                restantes++;
                dprintf(fd2, "%s\n", line);
            }
            j = 0;
        } else if (j < 63) line[j++] = c;
    }
    if (j > 0) {
        line[j] = '\0';
        if ((pid_t)atoi(line) != pid_to_delete) {
            restantes++;
            dprintf(fd2, "%s\n", line);
        }
    }
    close(fd1); close(fd2);
    unlink(FILE_PIDS);
    if (restantes == 0) {
        unlink(aux);
        unlink(FILE_TARGET);
        unlink(FILE_VOTOS);
    } else {
        rename(aux, FILE_PIDS);
    }
}

// funcion principal del minero
void ejecutar_minero(int n_secs, int n_threads, int pipe_escritura, int pipe_lectura) {
    pid_t pid = getpid();
    sem_t *sem;
    sem_t *sem_winner;
    sigset_t mask_all, mask_old;
    struct sigaction act;
    int ganador = 0, init_target = 0, monedas = 0, ronda = 0;

    // bloquear señales
    sigemptyset(&mask_all);
    sigaddset(&mask_all, SIGUSR1);
    sigaddset(&mask_all, SIGUSR2);
    sigaddset(&mask_all, SIGALRM);
    sigaddset(&mask_all, SIGINT);
    sigprocmask(SIG_BLOCK, &mask_all, &mask_old);

    // instalar handlers
    act.sa_handler = handler;
    sigemptyset(&act.sa_mask);
    sigaddset(&act.sa_mask, SIGUSR1);
    sigaddset(&act.sa_mask, SIGUSR2);
    sigaddset(&act.sa_mask, SIGALRM);
    sigaddset(&act.sa_mask, SIGINT);
    act.sa_flags = 0;
    sigaction(SIGALRM, &act, NULL);
    sigaction(SIGUSR1, &act, NULL);
    sigaction(SIGUSR2, &act, NULL);
    sigaction(SIGINT, &act, NULL);

    // abrir semaforos
    sem = sem_open(SEM_NAME, O_CREAT, 0644, 1);
    if (sem == SEM_FAILED) {
        perror("sem_open");
        exit(EXIT_FAILURE);
    }

    sem_winner = sem_open(SEM_WINNER, O_CREAT, 0644, 1);
    if (sem_winner == SEM_FAILED) {
        perror("sem_open winner");
        sem_close(sem);
        sem_unlink(SEM_NAME);
        exit(EXIT_FAILURE);
    }

    // registrar este minero en el sistema
    sem_wait(sem);
    int num_mineros = contar_mineros_en_fichero();
    if (num_mineros == 0) {
        ganador = 1;
    } else {
        ganador = 0;
    }
    escritura_de_ficheroPIDS(pid);
    leer_Target(pid, &init_target);
    sem_post(sem);

    alarm(n_secs);

    // si soy el primer minero, esperar a que haya al menos 2
    if (ganador) {
        while (!got_SIGALRM && !got_SIGINT) {
            sem_wait(sem);
            int n = contar_mineros_en_fichero();
            sem_post(sem);
            if (n >= 2) break;
            sleep(1);
        }
        if (got_SIGALRM || got_SIGINT) goto final;
        
        // iniciar primera ronda
        sem_wait(sem);
        limpiar_votos();
        sem_post(sem);
        notificar_a_todos(pid, SIGUSR1);
        got_SIGUSR1 = 1;
    }

    // bucle principal
    while (!got_SIGALRM && !got_SIGINT) {
        // inicio de ronda
        if (ganador) {
            if (ronda > 0) {
                while (!got_SIGALRM && !got_SIGINT) {
                    sem_wait(sem);
                    int n = contar_mineros_en_fichero();
                    sem_post(sem);
                    if (n >= 2) break;
                    sleep(1);
                }
                if (got_SIGALRM || got_SIGINT) break;
            }
            
            sem_wait(sem);
            limpiar_votos();
            sem_post(sem);
            notificar_a_todos(pid, SIGUSR1);
            got_SIGUSR1 = 1;
        } else {
            while (!got_SIGUSR1 && !got_SIGALRM && !got_SIGINT)
                sigsuspend(&mask_old);
            if (got_SIGALRM || got_SIGINT) break;
        }

        got_SIGUSR1 = 0;
        ronda++;

        sem_wait(sem);
        leer_Target(pid, &init_target);
        sem_post(sem);

        // minado
        int target_ronda = init_target;
        int found = -1;

        pthread_t *threads = malloc(n_threads * sizeof(pthread_t));
        int range = POW_LIMIT / n_threads;

        for (int i = 0; i < n_threads; i++) {
            Rank* r = malloc(sizeof(Rank));
            r->start  = i * range;
            r->stop   = (i + 1) * range;
            r->target = target_ronda;
            r->found  = &found;
            if((pthread_create(&threads[i], NULL, powRank, r) != 0)){
                free(threads);
                exit(EXIT_FAILURE);
            }
        }

        for (int i = 0; i < n_threads; i++)
            pthread_join(threads[i], NULL);

        free(threads);

        // resultado de ronda con sem_trywait
        if (found != -1 && !got_SIGUSR2) {
            // intentar ser el ganador
            if (sem_trywait(sem_winner) == 0) {
                // soy el ganador
                
                sem_wait(sem);
                escribir_Target(found);
                sem_post(sem);

                // enviar mensaje al monitor por cola de mensajes (apartado b)
                mqd_t mq;
                int intentos_cola = 0;
                do {
                    mq = mq_open(MQ_NAME_MINER, O_WRONLY);
                    if (mq == (mqd_t)-1 && intentos_cola < 5) {
                        sleep(1);
                        intentos_cola++;
                    } else {
                        break;
                    }
                } while (intentos_cola < 5);
                
                if (mq != (mqd_t)-1) {
                    MqMessage msg_monitor;
                    msg_monitor.objetivo = target_ronda;
                    msg_monitor.solucion = found;
                    msg_monitor.es_fin = 0;
                    
                    mq_send(mq, (char*)&msg_monitor, sizeof(MqMessage), 1);
                    mq_close(mq);
                }

                // enviar mensaje por pipe al registrador
                Message msg = {target_ronda, found, ronda};
                write(pipe_escritura, &msg, sizeof(Message));
                char ack;
                read(pipe_lectura, &ack, 1);

                notificar_a_todos(pid, SIGUSR2);

                got_SIGUSR2 = 0;
                votar(target_ronda, sem);

                // esperar a que voten todos
                int intentos = 0;
                int votos_actuales, mineros_actuales;
                do {
                    sem_wait(sem);
                    votos_actuales = contar_votos();
                    mineros_actuales = contar_mineros_en_fichero();
                    sem_post(sem);
                    
                    if (votos_actuales >= mineros_actuales) break;
                    
                    usleep(100000);
                    intentos++;
                } while (intentos < MAX_VOTOS_INTENTOS && !got_SIGALRM && !got_SIGINT);

                contar_y_mostrar_votos(pid, &monedas, sem);
                ganador = 1;
                
                sem_post(sem_winner);
                
            } else {
                // no soy el ganador
                while (!got_SIGUSR2 && !got_SIGALRM && !got_SIGINT)
                    sigsuspend(&mask_old);
                if (got_SIGALRM || got_SIGINT) goto final;

                votar(target_ronda, sem);
                got_SIGUSR2 = 0;
                ganador = 0;
            }
        } else {
            // votante normal
            while (!got_SIGUSR2 && !got_SIGALRM && !got_SIGINT)
                sigsuspend(&mask_old);
            if (got_SIGALRM || got_SIGINT) goto final;

            votar(target_ronda, sem);
            got_SIGUSR2 = 0;
            ganador = 0;
        }
    }

final:
    // final: limpiar recursos
    sem_wait(sem);
    notificar_a_todos(pid, SIGUSR1);  
    notificar_a_todos(pid, SIGUSR2);  
    borrado_de_ficheros(pid);
    int rest = contar_mineros_en_fichero();
    sem_post(sem);
    
    if (rest == 0) {
        Message fin = {0, -1, 0};
        write(pipe_escritura, &fin, sizeof(Message));
        
        // enviar mensaje de finalizacion al monitor
        mqd_t mq = mq_open(MQ_NAME_MINER, O_WRONLY);
        if (mq != (mqd_t)-1) {
            MqMessage msg_fin;
            msg_fin.objetivo = 0;
            msg_fin.solucion = -1;
            msg_fin.es_fin = 1;
            
            mq_send(mq, (char*)&msg_fin, sizeof(MqMessage), 1);
            mq_close(mq);
        }
        
        close(pipe_escritura);
        close(pipe_lectura);
    }
    
    sem_close(sem);
    sem_unlink(SEM_NAME);
    sem_close(sem_winner);
    sem_unlink(SEM_WINNER);
    
    exit(EXIT_SUCCESS);
}