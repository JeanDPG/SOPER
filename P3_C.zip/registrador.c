#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include "registrador.h"
#include "definiciones.h"

#define MAX_FILENAME 64

volatile sig_atomic_t got_SIGTERM = 0;

void registrador_handler(int sig) {
    if (sig == SIGTERM) got_SIGTERM = 1;
}

void ejecutar_registrador(int pipe_lectura, int pipe_escritura, pid_t ppid) {
    char filename[MAX_FILENAME];
    Message msg;
    FILE *log_file = NULL;
    int should_exit = 0;
    
    // Bloquear SIGTERM para manejarlo correctamente
    struct sigaction act;
    act.sa_handler = registrador_handler;
    sigemptyset(&act.sa_mask);
    act.sa_flags = 0;
    sigaction(SIGTERM, &act, NULL);
    
    // Crear nombre del fichero: PID.txt
    snprintf(filename, sizeof(filename), "%d.txt", ppid);
    
    // Abrir fichero para escribir (modo append)
    log_file = fopen(filename, "a");
    if (log_file == NULL) {
        fprintf(stderr, "Registrador %d: Error opening file %s\n", getpid(), filename);
        close(pipe_lectura);
        close(pipe_escritura);
        exit(EXIT_FAILURE);
    }
    
    fprintf(log_file, "=== Registrador iniciado para proceso %d ===\n", ppid);
    fflush(log_file);
    
    // Bucle principal: recibir mensajes del minero
    while (!should_exit && !got_SIGTERM) {
        ssize_t n = read(pipe_lectura, &msg, sizeof(Message));
        
        if (n == -1) {
            if (errno == EINTR) continue;
            perror("registrador read");
            break;
        }
        
        if (n == 0) {
            // Pipe cerrado por el minero
            break;
        }
        
        if (n == sizeof(Message)) {
            // Mensaje recibido correctamente
            
            if (msg.solution == -1) {
                // Mensaje especial de finalización
                fprintf(log_file, "=== FIN DEL SISTEMA ===\n");
                fflush(log_file);
                should_exit = 1;
            } else {
                // Mensaje normal: ronda con solución encontrada
                fprintf(log_file, "Ronda %d: Objetivo = %08d, Solución = %08d\n", 
                        msg.ronda, msg.target, msg.solution);
                fflush(log_file);
            }
            
            // Enviar ACK al minero
            char ack = '1';
            if (write(pipe_escritura, &ack, 1) == -1) {
                perror("registrador write ack");
                break;
            }
        }
    }
    
    // Cerrar fichero y pipes
    if (log_file != NULL) {
        fprintf(log_file, "=== Registrador terminado ===\n");
        fclose(log_file);
    }
    
    close(pipe_lectura);
    close(pipe_escritura);
    exit(EXIT_SUCCESS);
}